SCAMSHIELD - SIMPLE WINDOWS SETUP

1. Install Node.js LTS: https://nodejs.org/
2. Install MongoDB Community Server: https://www.mongodb.com/try/download/community
   During MongoDB setup, keep the option to install/run it as a Windows Service enabled if offered.
3. Extract this ZIP to a normal folder (for example Desktop\ScamShield).
4. Double-click START_SCAMSHIELD.bat
5. The first run installs project packages automatically and creates the .env file automatically.
6. When the website opens, go to http://localhost:5000 and create an account.

IMPORTANT:
- Keep the black terminal window open while using the app.
- If you see a MongoDB connection message, MongoDB is not running or is not installed.
- This project uses a local MongoDB database by default. You do not need to edit .env for a normal local setup.
- If Node.js is missing, install it from nodejs.org and run START_SCAMSHIELD.bat again.
- The URL score is an educational heuristic, not a guaranteed malware/phishing verdict.
