const mongoose = require("mongoose");

const reportSchema = new mongoose.Schema({
  referenceCode: { type: String, required: true, unique: true, index: true },
  reporter: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  category: {
    type: String,
    enum: ["Phishing", "Fake shopping", "Impersonation", "Investment", "Job scam", "Payment fraud", "Other"],
    required: true
  },
  description: { type: String, required: true, minlength: 20, maxlength: 3000, trim: true },
  url: { type: String, maxlength: 2048, default: "" },
  domain: { type: String, maxlength: 253, default: "" },
  city: { type: String, maxlength: 80, trim: true, default: "" },
  incidentDate: { type: Date, default: null },
  status: { type: String, enum: ["Pending", "Under review", "Verified", "Rejected"], default: "Pending" },
  moderatorNote: { type: String, maxlength: 1000, default: "" },
  isPublished: { type: Boolean, default: false }
}, { timestamps: true });

reportSchema.index({ domain: 1, category: 1, createdAt: -1 });
reportSchema.index({ status: 1, createdAt: -1 });

module.exports = mongoose.model("Report", reportSchema);
