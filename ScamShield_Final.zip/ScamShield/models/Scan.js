const mongoose = require("mongoose");

const scanSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
  submittedUrl: { type: String, required: true, maxlength: 2048 },
  normalizedUrl: { type: String, required: true, maxlength: 2048 },
  domain: { type: String, required: true, maxlength: 253 },
  score: { type: Number, required: true, min: 0, max: 100 },
  level: { type: String, enum: ["Low", "Moderate", "High"], required: true },
  indicators: [{ type: String, maxlength: 200 }],
  createdAt: { type: Date, default: Date.now, expires: 60 * 60 * 24 * 180 }
});

module.exports = mongoose.model("Scan", scanSchema);
