const mongoose = require("mongoose");

const alertSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 120 },
  message: { type: String, required: true, trim: true, maxlength: 2000 },
  category: { type: String, default: "General", maxlength: 60 },
  domain: { type: String, default: "", maxlength: 253 },
  published: { type: Boolean, default: true },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }
}, { timestamps: true });

module.exports = mongoose.model("Alert", alertSchema);
