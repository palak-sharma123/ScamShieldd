async function api(url, options = {}) {
  const res = await fetch(url, { ...options, headers: { ...(options.headers || {}), ...(options.body ? { "Content-Type": "application/json" } : {}) } });
  const data = await res.json();
  if (!res.ok) throw Object.assign(new Error(data.message || "Request failed."), { status: res.status });
  return data;
}
function el(tag, cls, text) { const n = document.createElement(tag); if (cls) n.className = cls; if (text !== undefined) n.textContent = text; return n; }
function statusPill(status) { return el("span", "pill " + String(status).toLowerCase().replace(/\s/g, "-"), status); }
function showEmpty(container, message) { container.replaceChildren(el("div", "empty", message)); }

async function loadDashboard() {
  try {
    const { user } = await api("/api/auth/me");
    document.getElementById("welcomeText").textContent = `Welcome, ${user.name}. Account role: ${user.role}.`;
    const [reportsData, scansData] = await Promise.all([api("/api/reports/mine"), api("/api/scans/mine")]);
    document.getElementById("reportCount").textContent = reportsData.reports.length;
    document.getElementById("scanCount").textContent = scansData.scans.length;
    const reportsList = document.getElementById("reportsList"); reportsList.replaceChildren();
    if (!reportsData.reports.length) showEmpty(reportsList, "No reports submitted yet.");
    reportsData.reports.forEach(r => {
      const item = el("div", "list-item");
      const info = el("div"); info.append(el("h3", "", `${r.referenceCode} · ${r.category}`), el("p", "", `${r.domain || "No URL supplied"} · ${new Date(r.createdAt).toLocaleString()}`));
      item.append(info, statusPill(r.status)); reportsList.append(item);
    });
    const scansList = document.getElementById("scansList"); scansList.replaceChildren();
    if (!scansData.scans.length) showEmpty(scansList, "No URL checks yet.");
    scansData.scans.forEach(s => {
      const item = el("div", "list-item"); const info = el("div");
      info.append(el("h3", "", s.domain), el("p", "", `${s.score}/100 · ${new Date(s.createdAt).toLocaleString()}`));
      item.append(info, statusPill(s.level)); scansList.append(item);
    });
    if (user.role === "admin") {
      document.getElementById("adminArea").classList.remove("hidden");
      await loadAdmin();
    }
  } catch (err) {
    if (err.status === 401) { window.location.href = "/login.html"; return; }
    document.getElementById("welcomeText").textContent = err.message;
  }
}
async function loadAdmin() {
  try {
    const data = await api("/api/admin/overview");
    const box = document.getElementById("adminOverview"); box.replaceChildren();
    box.append(el("p", "", `Users: ${data.totalUsers} · Reports: ${data.totalReports} · Pending/review: ${data.pendingReports} · Verified: ${data.verifiedReports}`));
    const reportsData = await api("/api/admin/reports?limit=30");
    const list = document.getElementById("adminReports"); list.replaceChildren();
    if (!reportsData.reports.length) showEmpty(list, "No reports to review.");
    reportsData.reports.forEach(r => {
      const item = el("div", "list-item"); const info = el("div");
      info.append(el("h3", "", `${r.referenceCode} · ${r.category}`), el("p", "", `${r.domain || "No URL"} · Reporter: ${r.reporter ? r.reporter.name : "Unknown"}`), el("p", "", r.description));
      const controls = el("div", "admin-actions");
      const select = document.createElement("select");
      ["Pending", "Under review", "Verified", "Rejected"].forEach(v => { const o = document.createElement("option"); o.value = v; o.textContent = v; if (v === r.status) o.selected = true; select.append(o); });
      const note = document.createElement("input"); note.placeholder = "Moderator note"; note.maxLength = 1000; note.value = r.moderatorNote || "";
      const save = el("button", "button button-small", "Save"); save.type = "button";
      save.addEventListener("click", async () => {
        save.disabled = true;
        try { await api("/api/admin/reports/" + r._id, { method: "PATCH", body: JSON.stringify({ status: select.value, moderatorNote: note.value }) }); await loadAdmin(); }
        catch (err) { alert(err.message); } finally { save.disabled = false; }
      });
      controls.append(select, note, save); info.append(controls); item.append(info); list.append(item);
    });
  } catch (err) { document.getElementById("adminOverview").textContent = err.message; }
}
document.getElementById("logoutBtn").addEventListener("click", async () => {
  await fetch("/api/auth/logout", { method: "POST" }); window.location.href = "/";
});
document.getElementById("refreshAdmin").addEventListener("click", loadAdmin);
document.getElementById("alertForm").addEventListener("submit", async e => {
  e.preventDefault(); const form = e.currentTarget; const msg = document.getElementById("adminMessage");
  try {
    const body = Object.fromEntries(new FormData(form).entries());
    const data = await api("/api/admin/alerts", { method: "POST", body: JSON.stringify(body) });
    msg.className = "message success"; msg.textContent = data.message; form.reset(); await loadAdmin();
  } catch (err) { msg.className = "message error"; msg.textContent = err.message; }
});
loadDashboard();
