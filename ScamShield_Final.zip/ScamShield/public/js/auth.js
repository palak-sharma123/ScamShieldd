async function sendForm(form, endpoint) {
  const message = document.getElementById("formMessage");
  const button = form.querySelector("button[type=submit]");
  button.disabled = true; message.textContent = "Please wait…"; message.className = "message";
  const body = Object.fromEntries(new FormData(form).entries());
  try {
    const response = await fetch(endpoint, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.message || "Request failed.");
    message.textContent = data.message; message.className = "message success";
    setTimeout(() => { window.location.href = "/dashboard.html"; }, 500);
  } catch (err) { message.textContent = err.message; message.className = "message error"; }
  finally { button.disabled = false; }
}
const loginForm = document.getElementById("loginForm");
if (loginForm) loginForm.addEventListener("submit", e => { e.preventDefault(); sendForm(loginForm, "/api/auth/login"); });
const registerForm = document.getElementById("registerForm");
if (registerForm) registerForm.addEventListener("submit", e => { e.preventDefault(); sendForm(registerForm, "/api/auth/register"); });
