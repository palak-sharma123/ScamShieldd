const form = document.getElementById("reportForm");
form.addEventListener("submit", async e => {
  e.preventDefault();
  const msg = document.getElementById("reportMessage");
  const btn = form.querySelector("button");
  btn.disabled = true; msg.className = "message"; msg.textContent = "Submitting…";
  const body = Object.fromEntries(new FormData(form).entries());
  if (!body.incidentDate) delete body.incidentDate;
  try {
    const res = await fetch("/api/reports", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const data = await res.json();
    if (res.status === 401) { window.location.href = "/login.html"; return; }
    if (!res.ok) throw new Error(data.message || "Could not submit report.");
    msg.className = "message success";
    msg.textContent = `Report submitted. Your reference number is ${data.report.referenceCode}. Status: ${data.report.status}.`;
    if (data.possibleRelatedReports && data.possibleRelatedReports.length) {
      const p = document.createElement("p"); p.textContent = "Potentially related reports exist. A moderator will review them."; msg.appendChild(p);
    }
    form.reset();
  } catch (err) { msg.className = "message error"; msg.textContent = err.message; }
  finally { btn.disabled = false; }
});
