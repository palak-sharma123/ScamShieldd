const container = document.getElementById("alertsList");
fetch("/api/alerts").then(r => r.json()).then(data => {
  container.replaceChildren();
  if (!data.alerts || !data.alerts.length) { const p = document.createElement("p"); p.className = "empty"; p.textContent = "No published alerts yet. Check back later."; container.append(p); return; }
  data.alerts.forEach(alert => {
    const card = document.createElement("article"); card.className = "alert-card";
    const meta = document.createElement("div"); meta.className = "meta";
    meta.textContent = `${alert.category || "General"} · ${new Date(alert.createdAt).toLocaleDateString()}`;
    const h = document.createElement("h3"); h.textContent = alert.title;
    const p = document.createElement("p"); p.textContent = alert.message;
    card.append(meta, h, p);
    if (alert.domain) { const d = document.createElement("p"); d.style.marginTop = "12px"; d.textContent = "Related domain: " + alert.domain; card.append(d); }
    container.append(card);
  });
}).catch(() => { container.textContent = "Could not load alerts. Please refresh the page."; });
