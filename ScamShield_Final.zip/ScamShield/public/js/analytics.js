const $ = (id) => document.getElementById(id);
const today = new Date();
const dateOnly = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const start = new Date(today); start.setDate(start.getDate()-13);
$('fromDate').value = dateOnly(start); $('toDate').value = dateOnly(today);
let map;
const cityCoords = {
  'ludhiana':[30.9010,75.8573], 'chandigarh':[30.7333,76.7794], 'amritsar':[31.6340,74.8723], 'jalandhar':[31.3260,75.5762], 'patiala':[30.3398,76.3869],
  'delhi':[28.6139,77.2090], 'new delhi':[28.6139,77.2090], 'mumbai':[19.0760,72.8777], 'pune':[18.5204,73.8567], 'bengaluru':[12.9716,77.5946], 'bangalore':[12.9716,77.5946], 'hyderabad':[17.3850,78.4867], 'chennai':[13.0827,80.2707], 'kolkata':[22.5726,88.3639], 'jaipur':[26.9124,75.7873], 'lucknow':[26.8467,80.9462], 'ahmedabad':[23.0225,72.5714], 'gurugram':[28.4595,77.0266], 'gurgaon':[28.4595,77.0266], 'noida':[28.5355,77.3910], 'bhopal':[23.2599,77.4126], 'indore':[22.7196,75.8577], 'surat':[21.1702,72.8311], 'kochi':[9.9312,76.2673], 'guwahati':[26.1445,91.7362], 'dehradun':[30.3165,78.0322], 'kanpur':[26.4499,80.3319], 'nagpur':[21.1458,79.0882], 'varanasi':[25.3176,82.9739], 'visakhapatnam':[17.6868,83.2185], 'agra':[27.1767,78.0081], 'jammu':[32.7266,74.8570]
};
function initMap(){
  const el = $('threatMap');
  if (!window.L) { el.innerHTML = '<p style="padding:20px">Map needs an internet connection to load its map tiles.</p>'; return; }
  map = L.map(el).setView([22.9734,78.6569], 4.5);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:18, attribution:'&copy; OpenStreetMap contributors'}).addTo(map);
}
function renderMap(cities){
  if (!map) return;
  map.eachLayer(layer => { if (layer instanceof L.CircleMarker) map.removeLayer(layer); });
  let shown=0;
  cities.forEach(item=>{
    const coords=cityCoords[String(item.city||'').trim().toLowerCase()];
    if (!coords) return;
    shown++;
    const marker=L.circleMarker(coords,{radius:Math.min(22,7+item.count*2),color:'#315eff',weight:2,fillColor:'#4776ff',fillOpacity:.65}).addTo(map);
    marker.bindPopup(`<strong>${escapeHtml(item.city)}</strong><br>${item.count} verified report${item.count===1?'':'s'}`);
  });
  $('mapLegend').textContent = shown ? `Showing ${shown} mapped cit${shown===1?'y':'ies'}. Only verified reports with recognized city names are plotted; no exact addresses are shown.` : 'No verified reports with recognized city names for this filter. Add a city to reports and have a moderator verify them.';
  if (shown) { const points=cities.filter(x=>cityCoords[String(x.city||'').trim().toLowerCase()]).map(x=>cityCoords[String(x.city).trim().toLowerCase()]); if(points.length>1) map.fitBounds(points,{padding:[25,25],maxZoom:6}); else map.setView(points[0],6); }
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function renderChart(daily,from,to){
  const counts={}; daily.forEach(x=>counts[x._id]=x.count);
  const dates=[]; const a=new Date(`${from}T12:00:00`), b=new Date(`${to}T12:00:00`);
  for(let d=new Date(a);d<=b;d.setDate(d.getDate()+1)) dates.push({key:dateOnly(d),label:d.toLocaleDateString('en-IN',{month:'short',day:'numeric'})});
  const recent=dates.slice(-14); const max=Math.max(1,...recent.map(x=>counts[x.key]||0));
  $('activityChart').innerHTML=recent.map(x=>{const n=counts[x.key]||0;const h=n?Math.max(6,Math.round(n/max*170)):4;return `<div class="chart-col" title="${x.label}: ${n} report(s)"><div class="chart-bar-area"><span class="chart-count">${n||''}</span><div class="chart-bar" data-count="${n}" style="height:${h}px"></div></div><span class="chart-date">${x.label}</span></div>`}).join('');
  $('chartEmpty').classList.toggle('hidden',recent.some(x=>(counts[x.key]||0)>0));
}
async function loadAnalytics(){
  const from=$('fromDate').value,to=$('toDate').value,category=$('category').value;
  if(!from||!to||from>to){$('analyticsStatus').textContent='Please choose a valid date range.';return;}
  $('analyticsStatus').textContent='Loading database metrics…';
  try{
    const q=new URLSearchParams({from,to});if(category)q.set('category',category);
    const res=await fetch(`/api/reports/analytics/summary?${q}`);const data=await res.json();if(!res.ok)throw new Error(data.message||'Unable to load analytics.');
    $('totalReports').textContent=data.counts.total;$('pendingReports').textContent=data.counts.pending;$('verifiedReports').textContent=data.counts.verified;$('rejectedReports').textContent=data.counts.rejected;
    renderChart(data.daily,from,to);renderMap(data.cities);
    $('recentRows').innerHTML=data.recent.length?data.recent.map(r=>`<tr><td>${escapeHtml(r.referenceCode)}</td><td>${escapeHtml(r.category)}</td><td>${escapeHtml(r.city||'Not provided')}</td><td>${new Date(r.createdAt).toLocaleDateString()}</td><td><span class="status-chip verified">Verified</span></td></tr>`).join(''):'<tr><td colspan="5">No verified reports in this date range.</td></tr>';
    $('analyticsStatus').textContent=`Showing database metrics from ${from} to ${to}${category?` for ${category}`:' for all categories'}.`;
  }catch(err){$('analyticsStatus').textContent=err.message;}
}
$('applyFilters').addEventListener('click',loadAnalytics);
$('exportCsv').addEventListener('click',async()=>{await loadAnalytics();const rows=[['Metric','Count'],['Total reports',$('totalReports').textContent],['Pending review',$('pendingReports').textContent],['Verified reports',$('verifiedReports').textContent],['Rejected reports',$('rejectedReports').textContent]];const csv=rows.map(r=>r.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\r\n');const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='scamshield-analytics-summary.csv';a.click();URL.revokeObjectURL(url);});
window.addEventListener('load',()=>{initMap();loadAnalytics();});
