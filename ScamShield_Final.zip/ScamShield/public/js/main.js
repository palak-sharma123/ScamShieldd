const authLink = document.getElementById("authLink");
fetch("/api/auth/me").then(r => r.ok ? r.json() : null).then(data => {
  if (data && authLink) { authLink.textContent = "My account"; authLink.href = "/dashboard.html"; }
}).catch(() => {});

const scanForm = document.getElementById("scanForm");
if (scanForm) {
  scanForm.addEventListener("submit", async event => {
    event.preventDefault();
    const resultBox = document.getElementById("scanResult");
    const button = scanForm.querySelector("button");
    button.disabled = true; button.textContent = "Analyzing…";
    resultBox.classList.remove("hidden");
    resultBox.textContent = "Checking URL indicators…";
    try {
      const response = await fetch("/api/scans", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: document.getElementById("urlInput").value })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "Could not analyze URL.");
      resultBox.replaceChildren();
      const top = document.createElement("div"); top.className = "result-top";
      const heading = document.createElement("div");
      const h = document.createElement("h3"); h.textContent = data.domain;
      const level = document.createElement("span"); level.className = "pill " + data.level.toLowerCase(); level.textContent = data.level + " risk indicators";
      heading.append(h, level);
      const score = document.createElement("div"); score.className = "score"; score.textContent = data.score + "/100";
      top.append(heading, score);
      const explanation = document.createElement("p"); explanation.textContent = data.disclaimer;
      const listTitle = document.createElement("h3"); listTitle.textContent = "What we noticed";
      const list = document.createElement("ul"); list.className = "indicator-list";
      data.indicators.forEach(reason => { const li = document.createElement("li"); li.textContent = reason; list.append(li); });
      resultBox.append(top, explanation, listTitle, list);
    } catch (err) {
      resultBox.textContent = err.message;
    } finally { button.disabled = false; button.textContent = "Analyze link"; }
  });
}
