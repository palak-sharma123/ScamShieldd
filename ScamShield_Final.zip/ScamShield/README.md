# ScamShield

ScamShield is a full-stack educational major project for screening suspicious URLs and reporting suspected online scams.

## Stack
- HTML, CSS, browser JavaScript
- Node.js and Express.js
- MongoDB and Mongoose
- JWT authentication in HttpOnly cookies
- bcrypt password hashing, Helmet security headers, rate limits

## Important limitations
- The URL score is a transparent heuristic, not a definitive malware/phishing verdict.
- The app does not visit, crawl, or fetch submitted URLs. This is intentional to reduce SSRF and tracking risks.
- User reports are allegations until reviewed by a moderator.
- Evidence file upload, email delivery, third-party threat intelligence, CAPTCHA, and production audit-log retention are future extensions, not included in this starter ZIP.
- This starter is suitable for local learning/demo. Before production, add CSRF protection appropriate to your deployment, robust audit logs, monitoring, backup/retention policies, and security review.

## Requirements
1. Node.js LTS (Node 20 or newer recommended).
2. MongoDB Community Server running locally, or a MongoDB Atlas connection string.
3. Internet access for `npm install`.

## Setup on Windows
1. Extract `ScamShield.zip` to a folder such as `C:\Projects\ScamShield`.
2. Open that folder in VS Code.
3. Open VS Code Terminal: **Terminal → New Terminal**.
4. Install dependencies:
   ```bash
   npm install
   ```
5. Copy `.env.example` to a new file named `.env`.
   - In VS Code Explorer, right-click `.env.example` → Copy, then Paste and rename the copy to `.env`.
   - Or in PowerShell:
     ```powershell
     Copy-Item .env.example .env
     ```
6. Edit `.env`. Set a unique `JWT_SECRET` (at least 24 characters). Example for local testing only:
   ```env
   PORT=5000
   MONGODB_URI=mongodb://127.0.0.1:27017/scamshield
   JWT_SECRET=local_dev_secret_change_to_a_long_random_value_123
   NODE_ENV=development
   ```
7. Start MongoDB Community Server, or use a MongoDB Atlas URI as `MONGODB_URI`.
8. Start the app:
   ```bash
   npm run dev
   ```
   If you do not want auto-restart, use `npm start`.
9. Open **http://localhost:5000** in your browser.

## First run
1. Open **Create account** and register a user with a valid email and a password of at least 10 characters.
2. Test URL screening from the homepage.
3. Log in and submit a report from **Report a scam**.
4. View report history in **Dashboard**.
5. To enable the admin dashboard, register the account you want to make admin first. Then stop the server with `Ctrl+C` and run:
   ```bash
   npm run make-admin -- your-email@example.com
   ```
   Restart with `npm run dev`, then log out and log in again. The account will now have admin access.
6. Admins can review reports and publish safety alerts from the dashboard.

## Troubleshooting
- **MongoDB connection error:** Check MongoDB service is running and `MONGODB_URI` is correct. For Atlas, check network access and database user permissions.
- **JWT_SECRET error:** Ensure `.env` exists in the project root and the secret is at least 24 characters.
- **Port already in use:** Change `PORT=5001` in `.env` and visit `http://localhost:5001`.
- **Cannot login after changing roles:** Log out and log in again.

## API overview
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/auth/me`
- `POST /api/scans`
- `GET /api/scans/mine` (login required)
- `POST /api/reports` (login required)
- `GET /api/reports/mine` (login required)
- `GET /api/alerts`
- `GET /api/admin/overview` (admin)
- `GET /api/admin/reports` (admin)
- `PATCH /api/admin/reports/:id` (admin)
- `POST /api/admin/alerts` (admin)
- `GET /api/admin/users` (admin)
- `PATCH /api/admin/users/:id/status` (admin)
- `GET /api/health`

## Suggested next upgrades
1. Add automated tests for risk rules, authentication, and report authorization.
2. Add an append-only audit log for admin actions.
3. Integrate a reputable URL reputation provider with API-key storage in environment variables.
4. Add safe file upload to private object storage with file type/size validation and malware scanning.
5. Add pagination to personal history and stronger abuse prevention.
6. Deploy with HTTPS, a managed database, restricted database network access, and secret management.


## Threat analytics and city map

Open `http://localhost:5000/analytics.html` to view report counts, a 14-day activity chart, recent verified reports, and a city-level map. The map loads OpenStreetMap tiles and therefore needs an internet connection. To include a report on the map, the report submitter can optionally enter a city; a moderator must verify it before it appears. Only recognized city names are mapped and no exact addresses are shown.
