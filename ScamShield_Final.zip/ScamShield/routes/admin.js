const router = require("express").Router();
const { requireAuth, requireAdmin } = require("../middleware/auth");
const Report = require("../models/Report");
const User = require("../models/User");
const Alert = require("../models/Alert");

router.use(requireAuth, requireAdmin);

router.get("/overview", async (req, res, next) => {
  try {
    const [totalReports, pendingReports, verifiedReports, totalUsers, categoryCounts] = await Promise.all([
      Report.countDocuments(),
      Report.countDocuments({ status: { $in: ["Pending", "Under review"] } }),
      Report.countDocuments({ status: "Verified" }),
      User.countDocuments(),
      Report.aggregate([{ $group: { _id: "$category", count: { $sum: 1 } } }, { $sort: { count: -1 } }])
    ]);
    res.json({ totalReports, pendingReports, verifiedReports, totalUsers, categoryCounts });
  } catch (err) { next(err); }
});

router.get("/reports", async (req, res, next) => {
  try {
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit = Math.min(50, Math.max(1, parseInt(req.query.limit, 10) || 20));
    const filter = {};
    if (["Pending", "Under review", "Verified", "Rejected"].includes(req.query.status)) filter.status = req.query.status;
    const [reports, total] = await Promise.all([
      Report.find(filter).populate("reporter", "name email").sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit),
      Report.countDocuments(filter)
    ]);
    res.json({ reports, page, limit, total, pages: Math.ceil(total / limit) });
  } catch (err) { next(err); }
});

router.patch("/reports/:id", async (req, res, next) => {
  try {
    const status = String(req.body.status || "");
    if (!["Pending", "Under review", "Verified", "Rejected"].includes(status)) {
      return res.status(400).json({ message: "Invalid status." });
    }
    const moderatorNote = String(req.body.moderatorNote || "").trim();
    if (moderatorNote.length > 1000) return res.status(400).json({ message: "Moderator note is too long." });
    const report = await Report.findByIdAndUpdate(req.params.id, {
      status, moderatorNote, isPublished: status === "Verified"
    }, { new: true, runValidators: true });
    if (!report) return res.status(404).json({ message: "Report not found." });
    res.json({ message: "Report updated.", report });
  } catch (err) { next(err); }
});

router.post("/alerts", async (req, res, next) => {
  try {
    const title = String(req.body.title || "").trim();
    const message = String(req.body.message || "").trim();
    if (title.length < 4 || title.length > 120 || message.length < 10 || message.length > 2000) {
      return res.status(400).json({ message: "Title must be 4–120 characters and message 10–2000 characters." });
    }
    const alert = await Alert.create({
      title, message, category: String(req.body.category || "General").slice(0, 60),
      domain: String(req.body.domain || "").slice(0, 253), createdBy: req.user._id, published: true
    });
    res.status(201).json({ message: "Alert published.", alert });
  } catch (err) { next(err); }
});

router.get("/users", async (req, res, next) => {
  try {
    const users = await User.find().sort({ createdAt: -1 }).limit(200).select("name email role isActive createdAt");
    res.json({ users });
  } catch (err) { next(err); }
});

router.patch("/users/:id/status", async (req, res, next) => {
  try {
    if (String(req.user._id) === req.params.id) return res.status(400).json({ message: "You cannot deactivate your own account." });
    if (typeof req.body.isActive !== "boolean") return res.status(400).json({ message: "isActive must be true or false." });
    const user = await User.findByIdAndUpdate(req.params.id, { isActive: req.body.isActive }, { new: true }).select("name email role isActive");
    if (!user) return res.status(404).json({ message: "User not found." });
    res.json({ message: "User updated.", user });
  } catch (err) { next(err); }
});

module.exports = router;
