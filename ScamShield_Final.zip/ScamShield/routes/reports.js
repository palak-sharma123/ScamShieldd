const router = require("express").Router();
const crypto = require("crypto");
const Report = require("../models/Report");
const { requireAuth } = require("../middleware/auth");

function cleanUrl(input) {
  if (!input) return { url: "", domain: "" };
  const raw = String(input).trim();
  if (raw.length > 2048) throw Object.assign(new Error("URL must be 2048 characters or fewer."), { status: 400 });
  let candidate = /^https?:\/\//i.test(raw) ? raw : "https://" + raw;
  let parsed;
  try { parsed = new URL(candidate); } catch { throw Object.assign(new Error("Enter a valid URL or leave the URL field empty."), { status: 400 }); }
  if (!["http:", "https:"].includes(parsed.protocol) || parsed.username || parsed.password) {
    throw Object.assign(new Error("Only HTTP/HTTPS URLs without embedded credentials are accepted."), { status: 400 });
  }
  return { url: parsed.href, domain: parsed.hostname.toLowerCase() };
}

router.post("/", requireAuth, async (req, res, next) => {
  try {
    const category = String(req.body.category || "");
    const description = String(req.body.description || "").trim();
    const incidentDate = req.body.incidentDate ? new Date(req.body.incidentDate) : null;
    const allowed = ["Phishing", "Fake shopping", "Impersonation", "Investment", "Job scam", "Payment fraud", "Other"];
    if (!allowed.includes(category)) return res.status(400).json({ message: "Choose a valid report category." });
    if (description.length < 20 || description.length > 3000) return res.status(400).json({ message: "Description must be 20–3000 characters." });
    if (incidentDate && Number.isNaN(incidentDate.getTime())) return res.status(400).json({ message: "Incident date is invalid." });
    const link = cleanUrl(req.body.url);
    const city = String(req.body.city || "").trim().slice(0, 80);
    const referenceCode = "SS-" + crypto.randomBytes(4).toString("hex").toUpperCase();
    const report = await Report.create({
      referenceCode, reporter: req.user._id, category, description,
      url: link.url, domain: link.domain, city, incidentDate
    });
    const duplicates = link.domain ? await Report.find({
      _id: { $ne: report._id }, domain: link.domain, category,
      status: { $in: ["Pending", "Under review", "Verified"] }
    }).sort({ createdAt: -1 }).limit(5).select("referenceCode category status createdAt") : [];
    res.status(201).json({
      message: "Report submitted for review.",
      report: { referenceCode: report.referenceCode, category: report.category, status: report.status, createdAt: report.createdAt },
      possibleRelatedReports: duplicates
    });
  } catch (err) { next(err); }
});

router.get("/mine", requireAuth, async (req, res, next) => {
  try {
    const reports = await Report.find({ reporter: req.user._id }).sort({ createdAt: -1 }).limit(100)
      .select("referenceCode category status createdAt domain moderatorNote");
    res.json({ reports });
  } catch (err) { next(err); }
});

// Public aggregate analytics; excludes reporter identities and exact addresses.
router.get("/analytics/summary", async (req, res, next) => {
  try {
    const from = req.query.from ? new Date(req.query.from + "T00:00:00.000Z") : new Date(Date.now() - 13 * 86400000);
    const to = req.query.to ? new Date(req.query.to + "T23:59:59.999Z") : new Date();
    if (Number.isNaN(from.getTime()) || Number.isNaN(to.getTime()) || from > to) return res.status(400).json({ message: "Choose a valid date range." });
    const category = String(req.query.category || "");
    const allowed = ["Phishing", "Fake shopping", "Impersonation", "Investment", "Job scam", "Payment fraud", "Other"];
    if (category && !allowed.includes(category)) return res.status(400).json({ message: "Choose a valid category." });
    const filter = { createdAt: { $gte: from, $lte: to }, ...(category ? { category } : {}) };
    const [total, pending, verified, rejected, daily, cities, recent] = await Promise.all([
      Report.countDocuments(filter), Report.countDocuments({ ...filter, status: { $in: ["Pending", "Under review"] } }),
      Report.countDocuments({ ...filter, status: "Verified" }), Report.countDocuments({ ...filter, status: "Rejected" }),
      Report.aggregate([{ $match: filter }, { $group: { _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } }, count: { $sum: 1 } } }, { $sort: { _id: 1 } }]),
      Report.aggregate([{ $match: { ...filter, status: "Verified", city: { $nin: ["", null] } } }, { $group: { _id: "$city", count: { $sum: 1 } } }, { $sort: { count: -1 } }, { $limit: 50 }]),
      Report.find({ ...filter, status: "Verified" }).sort({ createdAt: -1 }).limit(10).select("referenceCode category city status createdAt -_id")
    ]);
    res.json({ from: from.toISOString(), to: to.toISOString(), counts: { total, pending, verified, rejected }, daily, cities: cities.map(x => ({ city: x._id, count: x.count })), recent });
  } catch (err) { next(err); }
});

module.exports = router;
