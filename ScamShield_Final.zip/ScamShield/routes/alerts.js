const router = require("express").Router();
const Alert = require("../models/Alert");

router.get("/", async (req, res, next) => {
  try {
    const alerts = await Alert.find({ published: true }).sort({ createdAt: -1 }).limit(100)
      .select("title message category domain createdAt");
    res.json({ alerts });
  } catch (err) { next(err); }
});

module.exports = router;
