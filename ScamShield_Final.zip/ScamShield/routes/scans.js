const router = require("express").Router();
const Scan = require("../models/Scan");
const { analyzeUrl } = require("../services/riskEngine");
const { requireAuth } = require("../middleware/auth");

router.post("/", async (req, res, next) => {
  try {
    const result = analyzeUrl(req.body.url);
    let userId = null;
    if (req.cookies && req.cookies.scamshield_token) {
      try {
        const jwt = require("jsonwebtoken");
        const User = require("../models/User");
        const payload = jwt.verify(req.cookies.scamshield_token, process.env.JWT_SECRET);
        const user = await User.findById(payload.id).select("_id isActive");
        if (user && user.isActive) userId = user._id;
      } catch (_) {}
    }
    const scan = await Scan.create({ ...result, user: userId });
    res.json({ ...result, scanId: scan._id, createdAt: scan.createdAt });
  } catch (err) { next(err); }
});

router.get("/mine", requireAuth, async (req, res, next) => {
  try {
    const scans = await Scan.find({ user: req.user._id }).sort({ createdAt: -1 }).limit(50).select("-__v");
    res.json({ scans });
  } catch (err) { next(err); }
});

module.exports = router;
