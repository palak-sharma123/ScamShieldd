const net = require("net");

function analyzeUrl(input) {
  if (typeof input !== "string" || input.length > 2048) {
    const err = new Error("Enter a URL under 2048 characters.");
    err.status = 400;
    throw err;
  }

  let candidate = input.trim();
  if (!candidate) {
    const err = new Error("Enter a URL to analyze.");
    err.status = 400;
    throw err;
  }
  if (!/^https?:\/\//i.test(candidate)) candidate = "https://" + candidate;

  let parsed;
  try {
    parsed = new URL(candidate);
  } catch {
    const err = new Error("That URL is not valid. Include a domain such as example.com.");
    err.status = 400;
    throw err;
  }

  if (!["http:", "https:"].includes(parsed.protocol) || !parsed.hostname || parsed.username || parsed.password) {
    const err = new Error("Only standard HTTP/HTTPS URLs without embedded credentials are accepted.");
    err.status = 400;
    throw err;
  }

  const host = parsed.hostname.toLowerCase().replace(/\.$/, "");
  const indicators = [];
  let score = 0;

  const add = (points, reason) => {
    score += points;
    indicators.push(reason);
  };

  if (parsed.protocol === "http:") add(15, "Uses HTTP rather than encrypted HTTPS.");
  if (net.isIP(host)) add(25, "The hostname is an IP address instead of a typical domain name.");
  if (host.includes("xn--")) add(15, "Contains an internationalized/punycode hostname; inspect it carefully.");
  if (host.split(".").length >= 5) add(10, "Contains an unusually deep subdomain structure.");
  if (host.length > 45) add(10, "Hostname is unusually long.");
  if ((host.match(/-/g) || []).length >= 3) add(10, "Hostname contains several hyphens.");
  if (candidate.length > 150) add(5, "URL is unusually long.");
  if (/%[0-9a-f]{2}/i.test(parsed.pathname + parsed.search)) add(5, "Path or query contains percent-encoded characters.");
  if (parsed.port && !["80", "443"].includes(parsed.port)) add(10, "Uses a non-standard web port.");

  const suspiciousTerms = ["verify", "wallet", "login", "password", "claim", "prize", "urgent", "payment", "gift", "secure"];
  const searchable = (host + parsed.pathname + parsed.search).toLowerCase();
  const matched = suspiciousTerms.filter(term => searchable.includes(term));
  if (matched.length) add(Math.min(20, matched.length * 5), "Contains potentially sensitive terms: " + matched.join(", ") + ".");

  const shorteners = ["bit.ly", "tinyurl.com", "t.co", "is.gd", "cutt.ly", "rb.gy"];
  if (shorteners.includes(host)) add(15, "Uses a URL-shortening service that hides the destination.");

  score = Math.min(100, score);
  const level = score >= 50 ? "High" : score >= 25 ? "Moderate" : "Low";
  if (!indicators.length) indicators.push("No listed heuristic indicators were detected. This does not prove the URL is safe.");

  return {
    submittedUrl: input.trim(),
    normalizedUrl: parsed.href,
    domain: host,
    score,
    level,
    indicators,
    disclaimer: "This is a heuristic screening, not a verdict. A low score does not guarantee safety, and a high score does not prove fraud."
  };
}

module.exports = { analyzeUrl };
