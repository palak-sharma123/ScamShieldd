@echo off
setlocal
cd /d "%~dp0"
title ScamShield - One Click Setup
color 0A

echo ==========================================
echo          SCAMSHIELD STARTER
 echo ==========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not installed.
  echo Install Node.js LTS from https://nodejs.org/ and run this file again.
  echo.
  pause
  exit /b 1
)

where npm >nul 2>nul
if errorlevel 1 (
  echo ERROR: npm was not found. Reinstall Node.js LTS and try again.
  pause
  exit /b 1
)

if not exist ".env" (
  echo Creating local configuration automatically...
  copy /y ".env.example" ".env" >nul
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$secret = -join ((48..57)+(65..90)+(97..122) | Get-Random -Count 48 | ForEach-Object {[char]$_}); $p='.env'; $c=Get-Content $p -Raw; $c=$c -replace 'JWT_SECRET=.*', ('JWT_SECRET='+$secret); Set-Content -Path $p -Value $c -Encoding ascii"
)

if not exist "node_modules" (
  echo Installing project packages. This happens only on the first run...
  call npm install
  if errorlevel 1 (
    echo.
    echo ERROR: Package installation failed. Check your internet connection.
    pause
    exit /b 1
  )
)

echo.
echo Checking local MongoDB at 127.0.0.1:27017...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$c=New-Object System.Net.Sockets.TcpClient; try {$a=$c.BeginConnect('127.0.0.1',27017,$null,$null); if(-not $a.AsyncWaitHandle.WaitOne(1500)){exit 1}; $c.EndConnect($a); exit 0} catch {exit 1} finally {$c.Close()}"
if errorlevel 1 (
  echo.
  echo MongoDB is not responding on this computer.
  echo Install/start MongoDB Community Server, OR update MONGODB_URI in .env to your MongoDB Atlas connection string.
  echo Help: https://www.mongodb.com/try/download/community
  echo.
  pause
  exit /b 1
)

echo.
echo Starting ScamShield at http://localhost:5000
echo Keep this window open while using the website.
start "" powershell -NoProfile -Command "Start-Sleep -Seconds 3; Start-Process 'http://localhost:5000'"
call npm start

echo.
echo ScamShield has stopped. Press any key to close this window.
pause >nul
