require("dotenv").config();
const mongoose = require("mongoose");
const User = require("../models/User");

async function main() {
  const email = String(process.argv[2] || "").trim().toLowerCase();
  if (!email) {
    console.error("Usage: npm run make-admin -- user@example.com");
    process.exitCode = 1;
    return;
  }
  await mongoose.connect(process.env.MONGODB_URI);
  const user = await User.findOneAndUpdate({ email }, { role: "admin" }, { new: true }).select("name email role");
  if (!user) console.error("No user found. Register this email in ScamShield first.");
  else console.log(`Admin role assigned to ${user.email}.`);
  await mongoose.disconnect();
}
main().catch(err => { console.error(err.message); process.exitCode = 1; });
